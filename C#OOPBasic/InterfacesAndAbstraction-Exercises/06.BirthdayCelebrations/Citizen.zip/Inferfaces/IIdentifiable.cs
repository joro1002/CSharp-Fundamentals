﻿public interface IIdentifiable
{
     string ID { get; }
}

