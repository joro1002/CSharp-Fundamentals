﻿public interface IBirthday
{
     string BirthDay { get;  }
}

