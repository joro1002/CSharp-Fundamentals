﻿public interface IBrowseInTheWorldWideWeb
{
    string Calling(string number);
}

