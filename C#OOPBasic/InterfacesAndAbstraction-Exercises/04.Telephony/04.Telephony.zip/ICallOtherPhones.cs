﻿public interface ICallOtherPhones
{
    string Browsing(string url);
}

