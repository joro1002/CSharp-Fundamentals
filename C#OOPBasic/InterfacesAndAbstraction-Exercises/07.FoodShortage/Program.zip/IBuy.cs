﻿public interface IBuy
{
    string Name { get; }
    int Food { get; }
    void BuyFood();
}

