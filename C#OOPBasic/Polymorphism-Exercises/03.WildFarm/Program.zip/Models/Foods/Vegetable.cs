﻿public class Vegetable : Food
{
    public Vegetable(double foodQuantity) : base(foodQuantity)
    {
    }
}