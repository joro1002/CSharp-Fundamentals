﻿public class Fruit : Food
{
    public Fruit(double foodQuantity) : base(foodQuantity)
    {
    }
}