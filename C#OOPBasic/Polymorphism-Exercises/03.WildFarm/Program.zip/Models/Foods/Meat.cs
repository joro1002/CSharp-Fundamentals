﻿public class Meat : Food
{
    public Meat(double foodQuantity) : base(foodQuantity)
    {
    }
}