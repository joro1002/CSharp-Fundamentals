﻿public class Seeds : Food
{
    public Seeds(double foodQuantity) : base(foodQuantity)
    {
    }
}
