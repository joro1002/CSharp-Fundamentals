﻿
interface ISoundProducable
{
    string ProduceSound();
}

